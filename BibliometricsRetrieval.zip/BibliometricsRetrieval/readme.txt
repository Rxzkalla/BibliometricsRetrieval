Program Name: bibliometrics.py

Location: ⁨⁨BibliometricsRetrieval/⁨venv⁩

Program Description:

- Searches PubMed for all the publications for each author in 'authors.txt', and adds them all too 'metrics.txt'.
- The program searches scimagojr.com for the journal for each publication. This is where it gathers the impact factor and h-index of the journal.

Requirements:

- requirements.txt

Potential Errors:

- Author has an error in their name in the 'authors.txt' file
- Author has  0 - 1 publications; should to be done manually
